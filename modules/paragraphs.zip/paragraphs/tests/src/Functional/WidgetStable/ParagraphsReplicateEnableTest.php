<?php

namespace Drupal\Tests\paragraphs\Functional\WidgetStable;

/**
 * Enables replicate module.
 *
 * @group paragraphs
 */

class ParagraphsReplicateEnableTest extends ParagraphsDuplicateFeatureTest {

  protected static $modules = [
    'replicate',
  ];

}
